WEBAPP BẮC NINH - PATCH 6 TRANG DỊCH VỤ VẬN HÀNH

Cách cài:
1. Giải nén file ZIP.
2. Copy toàn bộ file và thư mục vào thư mục gốc dự án:
   C:\laragon\www\webappbacninh-php
3. Chọn Replace / Ghi đè.
4. Nhấn Ctrl + F5 trên trình duyệt.

Trang mới:
- hosting-bao-tri-website.php
- quan-tri-dang-bai-website.php
- seo-website.php
- noi-dung-facebook.php
- nang-cap-tich-hop-website.php
- do-luong-bao-cao-website.php

Nội dung 6 trang chỉnh tại:
- app/Data/operation_services.php

View dùng chung:
- resources/views/operations/show.php

CSS riêng:
- public/assets/css/operation-service-detail.css

Patch cũng cập nhật:
- Trang tổng Dịch vụ vận hành: 6 ô bấm sang trang chi tiết.
- Menu desktop và mobile: 6 link thật, có trạng thái active.
- Footer: link sang các trang chi tiết.
